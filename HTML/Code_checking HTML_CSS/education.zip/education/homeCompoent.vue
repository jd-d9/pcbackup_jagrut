<template>
    <div class="container">
        <div class="builder__preview-main-section grid__item medium--two-thirds large--two-thirds" style="height: 627px;">
        <div class="display-table">
          <div class="display-table-cell">
            <div class="builder__preview-column" style="opacity: 1; width: 563.892px;">
              <div class="builder__preview-section builder__preview-section-1" style="padding-left: 56.9459px; width: 563.892px;">
                <div class="builder__preview-top-wrap" style="height: 56.9459px; width: 450px;">
                  <div class="guillotine-window" style="width: 100%; height: auto; padding-top: 78.5714%;">
                    <div class="guillotine-canvas" style="width: 100%; height: 104.25%; top: -2.12%; left: 0%;">
                      <img class="builder__preview-image" src="https://cdn.filestackcontent.com/rotate%3Ddeg:exif/output%3Dformat:jpg/quality%3Dvalue:40/iwuIjdoZTgqfmn5bzA4A" style="perspective: 1000px; backface-visibility: hidden;">
                    </div>
                  </div>
                </div>

                <div class="builder__preview-right-wrap" style="width: 56.9459px; height: 358px;">
                  <div class="guillotine-window" style="padding-top: 78.5714%; height: 358px; width: 450px;">
                    <div class="guillotine-canvas" style="width: 100%; height: 104.25%; top: -2.12%; right: 0px; left: auto;">
                      <img class="builder__preview-image" src="https://cdn.filestackcontent.com/rotate%3Ddeg:exif/output%3Dformat:jpg/quality%3Dvalue:40/iwuIjdoZTgqfmn5bzA4A" style="perspective: 1000px; backface-visibility: hidden; margin-left: 0px;">
                    </div>
                  </div>
                </div>

                <div class="builder__preview-wrap">
                  <div class="guillotine-window" style="width: 100%; height: auto; padding-top: 78.5714%;"><div class="guillotine-canvas" style="width: 100%; height: 104.25%; top: -2.12%; left: 0%;"><img class="builder__preview-main-image" src="https://cdn.filestackcontent.com/rotate%3Ddeg:exif/output%3Dformat:jpg/quality%3Dvalue:40/iwuIjdoZTgqfmn5bzA4A" style="perspective: 1000px; backface-visibility: hidden;"></div></div>
                </div>

                <div class="builder__preview-bottom-wrap" style="height: 56.9459px; width: 450px;">
                  <div class="builder__preview-bottom-inner">
                    <div class="guillotine-window" style="width: 100%; height: auto; padding-top: 78.5714%;">
                      <div class="guillotine-canvas" style="width: 100%; height: 104.25%; top: -2.12%; left: 0%;">
                        <img class="builder__preview-image" src="https://cdn.filestackcontent.com/rotate%3Ddeg:exif/output%3Dformat:jpg/quality%3Dvalue:40/iwuIjdoZTgqfmn5bzA4A" style="perspective: 1000px; backface-visibility: hidden; margin-top: 0px;">
                      </div>
                    </div>
                  </div>
                </div>

                <div class="builder__preview-left-wrap" style="width: 56.9459px; top: 56.9459px; height: 358px;">
                  <div class="guillotine-window" style="padding-top: 78.5714%; height: 358px; width: 450px;">
                    <div class="guillotine-canvas" style="width: 100%; height: 104.25%; top: -2.12%; left: 0%;">
                      <img class="builder__preview-image" src="https://cdn.filestackcontent.com/rotate%3Ddeg:exif/output%3Dformat:jpg/quality%3Dvalue:40/iwuIjdoZTgqfmn5bzA4A" style="perspective: 1000px; backface-visibility: hidden;">
                    </div>
                  </div>
                </div>
              </div>

              

              
            </div>

            <div class="clearfix"></div>

            <div class="builder__preview-warning"></div>

            <div class="builder__zoom-controls">
              <h5>Zoom Photo</h5>
              <button class="zoom-out-button" data-tf-inspect="-1996016692"><span class="icon icon-minus-circle"></span></button>
              <input type="range" step="0.02" min="1.27" max="6.35" class="zoom-range">
              <button class="zoom-in-button" data-tf-inspect="-1996016692"><span class="icon icon-plus-circle"></span></button>
            </div>
          </div>
        </div>
      </div>
    </div>
</template>

<script>
    export default {
        mounted() {
            console.log('Component mounted.')
        },
        methods:{
        }
    }
</script>
